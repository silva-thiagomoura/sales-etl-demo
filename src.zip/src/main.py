import os
from pyspark.sql import SparkSession

from src.config import load_config
from src.logger import setup_logger
from src.extract import extract_sales_csv
from src.transform import transform_sales
from src.load import load_sales_incremental

def get_spark(cfg):
    spark = (
        SparkSession.builder
        .master(cfg["spark"]["master"])
        .appName(cfg["spark"]["app_name"])
        .config("spark.sql.shuffle.partitions", cfg["spark"]["shuffle_partitions"])
        .getOrCreate()
    )
    return spark

def main():
    logger = setup_logger()

    spark = None

    try:
        logger.info("Starting Sales ETL...")

        cfg = load_config()
        logger.info("Config loaded successfully")

        spark = get_spark(cfg)
        logger.info("Spark session created")

        raw_path = os.path.join(cfg["paths"]["raw_data_dir"], "sales.csv")
        state_path = os.path.join(cfg["paths"]["state_dir"], "watermark.json")

        logger.info(f"Extracting data from: {raw_path}")
        raw_df = extract_sales_csv(spark, raw_path)

        logger.info("Transforming data (DQ + schema mapping)")
        transformed_df = transform_sales(raw_df, cfg)

        logger.info("Loading data into Postgres (incremental)")
        load_sales_incremental(transformed_df, cfg, state_path, logger=logger)

        logger.info("ETL finished successfully")

    except Exception as e:
        logger.exception(f"ETL failed with error: {str(e)}")
        raise

    finally:
        if spark:
            spark.stop()
            logger.info("Spark stopped")

if __name__ == "__main__":
    main()
