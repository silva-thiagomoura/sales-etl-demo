from pyspark.sql import functions as F
from pyspark.sql.types import IntegerType, StringType

def transform_sales(df, cfg):

    # Schema evolution: if required columns are missing, create them
    required_cols = ["transaction_id", "customer_id", "product_id", "quantity", "timestamp"]
    for c in required_cols:
        if c not in df.columns:
            df = df.withColumn(c, F.lit(None).cast(StringType()))

    # Casts
    df = (
        df.withColumn("transaction_id", F.col("transaction_id").cast(IntegerType()))
          .withColumn("customer_id", F.col("customer_id").cast(IntegerType()))
          .withColumn("product_id", F.col("product_id").cast(IntegerType()))
          .withColumn("quantity", F.col("quantity").cast(IntegerType()))
          .withColumn("timestamp", F.to_timestamp("timestamp"))
    )

    # Data Quality Checks (missing values)
    df = df.filter(F.col("transaction_id").isNotNull())
    df = df.filter(F.col("customer_id").isNotNull())
    df = df.filter(F.col("product_id").isNotNull())
    df = df.filter(F.col("quantity").isNotNull())
    df = df.filter(F.col("timestamp").isNotNull())

    # Outliers
    df = df.filter((F.col("quantity") > 0) & (F.col("quantity") <= 100))

    # Transform schema: timestamp -> sale_date
    df = df.withColumn("sale_date", F.to_date("timestamp"))

    # Final schema for destination
    df = df.select(
        "transaction_id",
        "customer_id",
        "product_id",
        "quantity",
        "sale_date"
    )

    return df
