import os
import json
from pyspark.sql import functions as F
from src.encryption import encrypt_ids

def read_watermark(path):
    if not os.path.exists(path):
        return None
    with open(path, "r") as f:
        return json.load(f).get("last_transaction_id")

def write_watermark(path, last_id):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump({"last_transaction_id": int(last_id)}, f)

def load_sales_incremental(df, cfg, state_path, logger=None):

    last_id = read_watermark(state_path)

    if last_id:
        if logger:
            logger.info(f"Incremental mode enabled. last_transaction_id={last_id}")
        df = df.filter(F.col("transaction_id") > F.lit(last_id))
    else:
        if logger:
            logger.info("No watermark found. Running full load (first run).")

    # If no new rows, stop early
    if df.rdd.isEmpty():
        if logger:
            logger.info("No new records found. Skipping load step.")
        return

    # Encrypt/hash IDs
    df = encrypt_ids(df)

    # Concurrency: Spark parallelism
    df = df.repartition(4)

    props = {
        "user": cfg["db"]["user"],
        "password": cfg["db"]["password"],
        "driver": cfg["db"]["driver"]
    }

    # Write to Postgres
    df.write.jdbc(
        url=cfg["db"]["url"],
        table=cfg["db"]["table"],
        mode="append",
        properties=props
    )

    # Update watermark
    max_id = df.agg(F.max("transaction_id").alias("max_id")).collect()[0]["max_id"]
    if max_id:
        write_watermark(state_path, max_id)
        if logger:
            logger.info(f"Watermark updated: last_transaction_id={max_id}")
