import os
import yaml
from dotenv import load_dotenv

load_dotenv()

def load_config(path="config.yaml"):
    with open(path, "r") as f:
        cfg = yaml.safe_load(f)

    db_password = os.getenv(cfg["db"]["password_env"])
    if not db_password:
        raise ValueError(f"DB password not found in env var: {cfg['db']['password_env']}")

    encryption_key = os.getenv("ENCRYPTION_KEY")
    if not encryption_key:
        raise ValueError("ENCRYPTION_KEY not found in environment variables")

    cfg["db"]["password"] = db_password
    cfg["security"] = {"encryption_key": encryption_key}

    return cfg
