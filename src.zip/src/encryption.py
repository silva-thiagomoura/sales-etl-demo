from pyspark.sql import functions as F

def encrypt_ids(df):
    return (
        df.withColumn("customer_id", F.sha2(F.col("customer_id").cast("string"), 256))
          .withColumn("product_id", F.sha2(F.col("product_id").cast("string"), 256))
    )
