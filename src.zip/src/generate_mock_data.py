import os
import random
import pandas as pd
from datetime import datetime, timedelta

def generate_mock_sales_csv(output_path: str, n_rows: int = 50000):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    base_time = datetime.now() - timedelta(days=10)

    rows = []
    for i in range(n_rows):
        transaction_id = i + 1
        customer_id = random.randint(1000, 5000)
        product_id = random.randint(1, 300)
        quantity = random.randint(1, 10)

        ts = base_time + timedelta(minutes=random.randint(0, 60 * 24 * 10))

        rows.append({
            "transaction_id": transaction_id,
            "customer_id": customer_id,
            "product_id": product_id,
            "quantity": quantity,
            "timestamp": ts.isoformat()
        })

    df = pd.DataFrame(rows)
    df.to_csv(output_path, index=False)
    print(f"Mock CSV generated: {output_path} ({n_rows} rows)")

if __name__ == "__main__":
    generate_mock_sales_csv("data/raw/sales.csv", n_rows=50000)
